MEDIAGUARD — FREE DEPLOYMENT
=============================

This package is prepared for a Render Free web service.

GitHub:
1. Create a repository named mediaguard.
2. Upload the CONTENTS of this folder (not the ZIP itself).
3. In Render choose New > Web Service and connect the repository.
4. Build Command: pip install -r requirements.txt
5. Start Command: bash start.sh
6. Choose the Free plan and deploy.

The service binds to 0.0.0.0 and uses Render's PORT automatically.

IMPORTANT:
Render Free is suitable for testing/demo use. It sleeps after inactivity and its local
filesystem is ephemeral, so the SQLite accounts/stories data are not a permanent
production database. For a real 24/7 MICT deployment, use a persistent database and
paid/always-on hosting.

News images:
The collector reads RSS/Atom media fields and image tags. Some publishers do not provide
image URLs, so those stories may still show the topic illustration.

Videos:
YouTube links are embedded where possible; direct MP4/WebM/OGG links play in-page.
Other sites may block embedding and will open at their source.
