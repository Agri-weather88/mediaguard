MEDIAGUARD SERVER
=================
Needs: an Ubuntu/Debian server you can SSH into, and (for https) a domain name pointing at it.

INSTALL
  1. Upload and unzip this folder on the server:   unzip mediaguard-server.zip && cd mediaguard-server
  2. Run:   sudo bash install.sh yourdomain.na you@email.com
  3. Open https://yourdomain.na and sign up. The FIRST account becomes the Administrator.

WHAT IT DOES
  - Serves the MediaGuard dashboard.
  - Collects the news feeds listed in /opt/mediaguard/feeds.json every 10 minutes
    (headline, link, summary, photo address). The dashboard picks up new stories every minute.
  - Provides real sign up, login, logout and password-reset requests (passwords are hashed,
    sessions use secure cookies, repeated tries are rate-limited).

DAY-TO-DAY
  Check collection:      curl http://127.0.0.1:8080/api/health
  Add a news source:     edit /opt/mediaguard/feeds.json then:  sudo systemctl restart mediaguard
  List accounts:         sudo -u mediaguard MG_DATA=/opt/mediaguard/data python3 /opt/mediaguard/server.py users
  Make someone admin:    ... server.py promote person@email.com
  Reset a password:      ... server.py passwd person@email.com     (prints a temporary password)
  See reset requests:    ... server.py resets
  Close public sign-up:  add  Environment=MG_SIGNUP=closed  to /etc/systemd/system/mediaguard.service
  Update the dashboard:  replace index.html in /opt/mediaguard and restart.

NOT INCLUDED (needs outside accounts)
  Social media posts (X, Facebook, Instagram, TikTok, YouTube, LinkedIn, Reddit) and radio/TV
  transcription need official API keys or a speech-to-text service. The dashboard has places
  for them (SOCIAL_URL, STREAMS_URL) and shows them as empty until connected.

Only use feeds you are allowed to use; check each outlet's terms. Photos are linked from the
original source, not copied.
