#!/usr/bin/env bash
# MediaGuard installer for Ubuntu/Debian.
# Usage:  sudo bash install.sh yourdomain.na you@email.com
#         sudo bash install.sh            (no domain: serves on port 80 without https)
set -euo pipefail
DOMAIN="${1:-}"; EMAIL="${2:-}"
[ "$(id -u)" = 0 ] || { echo "Please run with sudo."; exit 1; }
cd "$(dirname "$0")"
apt-get update -y
apt-get install -y python3 nginx
id mediaguard >/dev/null 2>&1 || useradd --system --home /opt/mediaguard --shell /usr/sbin/nologin mediaguard
mkdir -p /opt/mediaguard/data
cp server.py index.html /opt/mediaguard/
[ -f /opt/mediaguard/feeds.json ] || cp feeds.json /opt/mediaguard/
chown -R mediaguard:mediaguard /opt/mediaguard

cat > /etc/systemd/system/mediaguard.service <<UNIT
[Unit]
Description=MediaGuard
After=network-online.target
[Service]
User=mediaguard
WorkingDirectory=/opt/mediaguard
Environment=MG_PORT=8080 MG_DATA=/opt/mediaguard/data
ExecStart=/usr/bin/python3 /opt/mediaguard/server.py
Restart=always
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now mediaguard
systemctl restart mediaguard

cat > /etc/nginx/sites-available/mediaguard <<NGX
server {
  listen 80;
  server_name ${DOMAIN:-_};
  location / {
    proxy_pass http://127.0.0.1:8080;
    proxy_set_header Host \$host;
    proxy_set_header X-Forwarded-For \$remote_addr;
    proxy_set_header X-Forwarded-Proto \$scheme;
  }
}
NGX
ln -sf /etc/nginx/sites-available/mediaguard /etc/nginx/sites-enabled/mediaguard
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

if [ -n "$DOMAIN" ] && [ -n "$EMAIL" ]; then
  apt-get install -y certbot python3-certbot-nginx
  certbot --nginx -d "$DOMAIN" -m "$EMAIL" --agree-tos --non-interactive --redirect
  echo "Done. Open https://$DOMAIN and create the first account. It becomes the Administrator."
else
  echo "Done. Open http://YOUR-SERVER-IP and create the first account. Add a domain and re-run with it to get https."
fi
echo "Check the news collector: curl http://127.0.0.1:8080/api/health"
