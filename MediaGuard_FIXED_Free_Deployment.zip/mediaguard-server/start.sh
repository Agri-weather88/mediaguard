#!/usr/bin/env bash
set -e
export MG_HOST=0.0.0.0
exec python3 server.py
