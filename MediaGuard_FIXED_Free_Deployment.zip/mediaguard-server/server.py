#!/usr/bin/env python3
"""MediaGuard server: serves the dashboard, collects public RSS feeds, and provides login.
Standard library only. Run:  python3 server.py
Admin helpers:  python3 server.py users | promote EMAIL | passwd EMAIL | resets"""
import json, os, re, sys, sqlite3, secrets, hashlib, hmac, threading, time, html, urllib.request
import xml.etree.ElementTree as ET
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get("MG_DATA", os.path.join(BASE, "data"))
PORT = int(os.environ.get("PORT", os.environ.get("MG_PORT", "8080")))
HOST = os.environ.get("MG_HOST", "0.0.0.0")
SIGNUP = os.environ.get("MG_SIGNUP", "open")          # open | closed (after the first admin exists)
INTERVAL = int(os.environ.get("MG_INTERVAL", "600"))  # seconds between news collections
os.makedirs(DATA, exist_ok=True)
DB = os.path.join(DATA, "mediaguard.db")
STORIES = os.path.join(DATA, "stories.json")
STATUS = {"last_run": None, "stories": 0, "feeds": {}}

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, role TEXT, salt TEXT, hash TEXT, created TEXT);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER, expires REAL);
    CREATE TABLE IF NOT EXISTS resets(id INTEGER PRIMARY KEY, email TEXT, created TEXT);""")
    return c

def hpw(pw, salt): return hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200000).hex()
def user_json(u): return {"id": u["id"], "name": u["name"], "email": u["email"], "role": u["role"]}

def make_user(c, name, email, pw, role):
    salt = secrets.token_hex(16)
    c.execute("INSERT INTO users(name,email,role,salt,hash,created) VALUES(?,?,?,?,?,?)",
              (name, email, role, salt, hpw(pw, salt), datetime.now(timezone.utc).isoformat()))
    c.commit()
    return c.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()

# ---------- news collection ----------
NS = {"media": "http://search.yahoo.com/mrss/", "content": "http://purl.org/rss/1.0/modules/content/"}
clean = lambda t: re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", t or ""))).strip()

def parse(xml_bytes, feed):
    """Parse RSS 2.0 or Atom feeds and extract article/video media when available."""
    out = []
    root = ET.fromstring(xml_bytes)
    atom = {"a": "http://www.w3.org/2005/Atom"}

    def text(el, names):
        for name in names:
            x = el.find(name)
            if x is not None and x.text:
                return x.text.strip()
        return ""

    items = list(root.iter("item"))
    atom_mode = not items
    if atom_mode:
        items = list(root.findall("a:entry", atom))

    for it in items:
        if atom_mode:
            title = text(it, ["a:title"])
            link = ""
            for le in it.findall("a:link", atom):
                href = (le.get("href") or "").strip()
                if href and (le.get("rel") in (None, "", "alternate")):
                    link = href
                    break
            body = text(it, ["a:content", "a:summary"])
            date_raw = text(it, ["a:published", "a:updated"])
            desc = text(it, ["a:summary"])
        else:
            g = lambda tag: (it.findtext(tag) or "").strip()
            title = g("title")
            link = g("link")
            body = it.findtext("content:encoded", namespaces=NS) or g("description")
            date_raw = g("pubDate") or g("dc:date")
            desc = g("description")

        if not link:
            continue

        img = ""
        video = ""

        # RSS/MediaRSS media
        for tag in ("media:content", "media:thumbnail"):
            m = it.find(tag, NS)
            if m is not None and m.get("url"):
                u = m.get("url").strip()
                typ = (m.get("type") or "").lower()
                if "video" in typ:
                    video = u
                elif not img:
                    img = u

        # RSS enclosure
        e = it.find("enclosure")
        if e is not None and e.get("url"):
            u = e.get("url").strip()
            typ = (e.get("type") or "").lower()
            if typ.startswith("image") and not img:
                img = u
            elif typ.startswith("video") and not video:
                video = u

        # Image in HTML description/content
        if not img:
            m = re.search(r'<img[^>]+(?:src|data-src)=["\']([^"\']+)["\']', body or "", re.I)
            if m:
                img = html.unescape(m.group(1))

        try:
            d = parsedate_to_datetime(date_raw).astimezone(timezone.utc)
        except Exception:
            try:
                d = datetime.fromisoformat(date_raw.replace("Z", "+00:00")).astimezone(timezone.utc)
            except Exception:
                d = datetime.now(timezone.utc)

        summ = clean(desc or body)
        out.append({
            "id": link, "headline": clean(title), "source": feed["source"],
            "type": feed.get("type", "Online News"), "scope": feed.get("scope", "local"),
            "date": d.strftime("%Y-%m-%d"), "time": d.strftime("%H:%M"),
            "url": link, "image": img, "video": video,
            "summary": summ[:240] + ("…" if len(summ) > 240 else "")
        })
    return out

def collect():
    try: feeds = json.load(open(os.path.join(BASE, "feeds.json"), encoding="utf-8"))
    except Exception as e: print("feeds.json problem:", e, file=sys.stderr); feeds = []
    stories, st = [], {}
    for f in feeds:
        try:
            req = urllib.request.Request(f["url"], headers={"User-Agent": "MediaGuard/1.0"})
            items = parse(urllib.request.urlopen(req, timeout=20).read(), f)
            stories += items; st[f["source"]] = {"ok": True, "items": len(items)}
        except Exception as e:
            st[f["source"]] = {"ok": False, "error": str(e)[:120]}; print("feed failed:", f["source"], e, file=sys.stderr)
    seen, uniq = set(), []
    for s in sorted(stories, key=lambda s: (s["date"], s["time"]), reverse=True):
        if s["id"] not in seen: seen.add(s["id"]); uniq.append(s)
    if uniq or not os.path.exists(STORIES):            # never wipe good data because of a network blip
        tmp = STORIES + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh: json.dump(uniq[:300], fh, ensure_ascii=False)
        os.replace(tmp, STORIES)
    STATUS.update(last_run=datetime.now(timezone.utc).isoformat(), stories=len(uniq), feeds=st)

def collector_loop():
    while True:
        try: collect()
        except Exception as e: print("collector error:", e, file=sys.stderr)
        time.sleep(INTERVAL)

# ---------- web ----------
HITS = {}
def limited(ip, n=10, win=300):
    now = time.time(); HITS[ip] = [t for t in HITS.get(ip, []) if now - t < win]
    if len(HITS[ip]) >= n: return True
    HITS[ip].append(now); return False

class H(BaseHTTPRequestHandler):
    server_version = "MediaGuard"
    def log_message(self, *a): pass
    def send(self, code, body, ctype="application/json", extra=None):
        b = body if isinstance(body, bytes) else body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith(("text", "application/json")) else ""))
        self.send_header("Content-Length", str(len(b))); self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        if ctype != "text/html" or extra is not None: self.send_header("Cache-Control", "no-store")
        for k, v in (extra or []): self.send_header(k, v)
        self.end_headers(); self.wfile.write(b)
    def js(self, code, obj, extra=None): self.send(code, json.dumps(obj), extra=extra or [])
    def secure(self): return self.headers.get("X-Forwarded-Proto") == "https"
    def cookie(self, token, age):
        return [("Set-Cookie", f"mg_session={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={age}" + ("; Secure" if self.secure() else ""))]
    def me(self, c):
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == "mg_session":
                r = c.execute("SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires>?", (v, time.time())).fetchone()
                return r, v
        return None, None
    def ip(self): return (self.headers.get("X-Forwarded-For") or self.client_address[0]).split(",")[0].strip()
    def do_GET(self):
        p = self.path.split("?")[0]
        if p in ("/", "/index.html"):
            page = open(os.path.join(BASE, "index.html"), encoding="utf-8").read()
            page = page.replace("const API='',FEED_URL='';", "const API=location.origin,FEED_URL='/stories.json';")
            return self.send(200, page, "text/html", extra=[("Cache-Control", "no-cache")])
        if p == "/stories.json":
            return self.send(200, open(STORIES, "rb").read() if os.path.exists(STORIES) else b"[]", extra=[("Cache-Control","no-store")])
        if p == "/api/health": return self.js(200, STATUS)
        if p == "/api/auth/me":
            c = db(); u, _ = self.me(c)
            return self.js(200, {"user": user_json(u)}) if u else self.js(401, {"message": "Not signed in."})
        self.send(404, "Not found", "text/plain")
    def do_POST(self):
        p = self.path.split("?")[0]; c = db()
        if p == "/api/auth/logout":
            u, tok = self.me(c)
            if tok: c.execute("DELETE FROM sessions WHERE token=?", (tok,)); c.commit()
            return self.js(200, {"ok": True}, self.cookie("", 0))
        if "application/json" not in (self.headers.get("Content-Type") or ""): return self.js(415, {"message": "JSON required."})
        try: d = json.loads(self.rfile.read(min(int(self.headers.get("Content-Length") or 0), 10000)) or b"{}")
        except Exception: return self.js(400, {"message": "Bad request."})
        em = str(d.get("email", "")).strip().lower(); pw = str(d.get("password", ""))
        if p == "/api/auth/forgot":
            if em and not limited(self.ip(), 5):
                c.execute("INSERT INTO resets(email,created) VALUES(?,?)", (em[:200], datetime.now(timezone.utc).isoformat())); c.commit()
            return self.js(200, {"ok": True})
        if p not in ("/api/auth/login", "/api/auth/register"): return self.js(404, {"message": "Not found."})
        if limited(self.ip()): return self.js(429, {"message": "Too many tries. Please wait a few minutes."})
        if p == "/api/auth/register":
            name = str(d.get("name", "")).strip()
            n = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            if n and SIGNUP == "closed": return self.js(403, {"message": "Sign-ups are closed. Ask your Administrator."})
            if len(name) < 2 or len(name) > 100: return self.js(400, {"message": "Please enter your full name."})
            if not re.match(r"^\S+@\S+\.\S+$", em) or len(em) > 200: return self.js(400, {"message": "Please enter a valid email address."})
            if len(pw) < 8: return self.js(400, {"message": "Use at least 8 characters for your password."})
            if c.execute("SELECT 1 FROM users WHERE email=?", (em,)).fetchone(): return self.js(409, {"message": "An account with this email already exists. Try signing in."})
            u = make_user(c, name, em, pw, "Administrator" if n == 0 else "Analyst")
        else:
            u = c.execute("SELECT * FROM users WHERE email=? OR lower(substr(email,1,instr(email,'@')-1))=?", (em, em)).fetchone()
            if not u or not hmac.compare_digest(hpw(pw, u["salt"]), u["hash"]): return self.js(401, {"message": "Wrong username/email or password."})
        tok = secrets.token_urlsafe(32)
        c.execute("DELETE FROM sessions WHERE expires<?", (time.time(),))
        c.execute("INSERT INTO sessions VALUES(?,?,?)", (tok, u["id"], time.time() + 30 * 86400)); c.commit()
        self.js(200, {"user": user_json(u)}, self.cookie(tok, 30 * 86400))

def cli(a):
    c = db()
    if a[0] == "users":
        for u in c.execute("SELECT id,name,email,role,created FROM users"): print(dict(u))
    elif a[0] == "resets":
        for r in c.execute("SELECT * FROM resets ORDER BY id DESC LIMIT 50"): print(dict(r))
    elif a[0] == "promote" and len(a) > 1:
        c.execute("UPDATE users SET role='Administrator' WHERE email=?", (a[1].lower(),)); c.commit(); print("done")
    elif a[0] == "passwd" and len(a) > 1:
        pw = secrets.token_urlsafe(9); salt = secrets.token_hex(16)
        c.execute("UPDATE users SET salt=?,hash=? WHERE email=?", (salt, hpw(pw, salt), a[1].lower())); c.commit()
        c.execute("DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE email=?)", (a[1].lower(),)); c.commit()
        print("Temporary password for", a[1], ":", pw)
    else: print(__doc__)

if __name__ == "__main__":
    if len(sys.argv) > 1: sys.exit(cli(sys.argv[1:]))
    db().close(); threading.Thread(target=collector_loop, daemon=True).start()
    print(f"MediaGuard running on http://{HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), H).serve_forever()
